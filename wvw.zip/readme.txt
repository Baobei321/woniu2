蜗牛TV 本地包（三站·含本地文件）说明　2026-11-20

一、解压到哪里（目录结构就是 /storage/emulated/0/wvw 本身）
解压时目标目录直接选 /storage/emulated/0/wvw/ ，不要再套一层文件夹。解开后应是：
  /storage/emulated/0/wvw/1_py.json
  /storage/emulated/0/wvw/2_js.json
  /storage/emulated/0/wvw/3_html.json
  /storage/emulated/0/wvw/py/本地影仓.py
  /storage/emulated/0/wvw/html/蜗牛.html
  /storage/emulated/0/wvw/webview.jar
  /storage/emulated/0/wvw/readme.txt
真正被壳读的是 py/、html/ 和 webview.jar 这三处；三个 json 只是导入用的配置，导入完可留可删。
json 里写的是绝对路径，文件别挪位置，挪了就对不上。

二、三站（名称 / 类型 / 依赖的本地文件）
1）py　py 站
   api: /storage/emulated/0/wvw/py/本地影仓.py
   依赖文件: /storage/emulated/0/wvw/py/本地影仓.py（1,057,951 字节）
2）js　js 站
   api: lib/drpy2.min.js，规则全文已内联在 json 的 ext 里
   依赖文件: 无（走壳内置的 drpy2 运行时，不需要外部 .js）
3）蜗牛　html 站
   api: csp_WvWv，jar: /storage/emulated/0/wvw/webview.jar
   依赖文件: /storage/emulated/0/wvw/webview.jar（49,889 字节，必须正好叫这个名字、放在 wvw 根）
             /storage/emulated/0/wvw/html/蜗牛.html（49,590 字节，ext 里的 url 指向这里）

三、导入顺序（壳一次只吃一个文件，所以分三份，逐份导）
1_py.json → 2_js.json → 3_html.json
每次都是：设置 → 源管理（智能写源页也有入口）→ 从文件添加 → 只选一个 json。
第三份要等 webview.jar 已经在 /wvw 根之后再导，jar 没到位导了也是空白。
成功提示形如：识别 1 个站点（接口 1 / 蜘蛛 0 / js 0）；写库 1，列表原 N 条、本次新增 +1。

四、列表里的名字
列表显示的是 json 的 name 字段，导入时写进去。同名 key 再导一次会覆盖列表里那条旧记录，名字跟着更新成 py / js / 蜗牛。
之前几版留下的旧名条目（蜗牛影视仓、蜗牛隐藏、蜗牛JS、蜗牛FM、蜗牛HTML、蜗牛、本地影仓、集多等）：
去 设置 → 源管理 里改名或删除即可；本包三份的 key 与旧版完全相同，重新导入会把对应那条改成新名字。

五、权限与自检
1）先给蜗牛TV「所有文件访问」权限，否则 /storage/emulated/0/wvw 下的绝对路径读不到。
2）文件自检：上面七个路径逐个确认；py 必须 .py 结尾（不是 .py.txt），jar 必须叫 webview.jar（不是 webview(1).jar）。
3）导入自检：三次导入提示里「缺文件」都必须是 0。
4）运行自检：三站进入后看分类与列表；html 空白先查 webview.jar 在不在，py 空白先查脚本要扫的源目录。

六、边界
- 一次只导一个 json，别合并成一个多站文件再导。
- 不要用 ./ 开头的 api/ext，也不要把 demo.json 整包导入（OK影视 的相对路径，蜗牛TV 不认）。
- 不要塞需要 vox.jar / WvSpider.jar / webview.jj 的站，本包刻意不含。
- 三份都是 type 3；路径按 w113 源码静态核对，未真机复验。
